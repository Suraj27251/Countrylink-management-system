<?php
$api_key = 'rzp_live_S2uFzG02Xbl4AA';
$api_secret = 'salaSrn0EG1Q4Uy70ASoofzd';

$ch = curl_init('https://api.razorpay.com/v1/orders');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERPWD, $api_key . ':' . $api_secret);

$result = curl_exec($ch);
if ($result === false) {
    echo 'Curl error: ' . curl_error($ch);
} else {
    echo 'Curl success: ' . $result;
}
curl_close($ch);
?>