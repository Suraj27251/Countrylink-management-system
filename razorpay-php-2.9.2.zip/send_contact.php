<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = htmlspecialchars($_POST['name'] ?? '');
    $email = htmlspecialchars($_POST['email'] ?? '');
    $number = htmlspecialchars($_POST['number'] ?? '');
    $message = htmlspecialchars($_POST['text'] ?? '');

    $to = "countrylinkq@gmail.com";
    $subject = "New Contact Form Submission";
    $body = "You have received a new message from the contact form.\n\n" .
            "Name: $name\n" .
            "Email: $email\n" .
            "Phone: $number\n" .
            "Message: $message\n";
    $headers = "From: $email\r\nReply-To: $email\r\n";

    if (mail($to, $subject, $body, $headers)) {
        echo '<script>alert("Thank you for contacting us! We will get back to you soon."); window.location = "contact.html";</script>';
    } else {
        echo '<script>alert("Sorry, there was an error sending your message. Please try again later."); window.location = "contact.html";</script>';
    }
} else {
    header("Location: contact.html");
    exit();
}
