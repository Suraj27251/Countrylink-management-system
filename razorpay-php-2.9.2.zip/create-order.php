
<?php
// Enable error logging for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_error.log');

use Razorpay\Api\Api;

header('Content-Type: application/json');
set_exception_handler(function($e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Fatal server error',
        'message' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
    exit;
});

try {
    // ✅ Load Razorpay SDK AUTOLOADER (THIS IS CRITICAL)
    require_once __DIR__ . '/razorpay-php-2.9.2/Razorpay.php';

    // ✅ Razorpay LIVE keys
    $keyId     = 'rzp_live_S2uFzG02Xbl4AA';
    $keySecret = 'salaSrn0EG1Q4Uy70ASoofzd';

    // ✅ Init API
    $api = new Api($keyId, $keySecret);

    // ✅ Read JSON input
    $rawInput = file_get_contents("php://input");
    $data = json_decode($rawInput, true);

    // ✅ Validate amount
    $amount = isset($data['amount']) ? (int)$data['amount'] : 0;

    // Debug: Log the received amount and input data
    file_put_contents(__DIR__ . '/order_debug.log', "[" . date('Y-m-d H:i:s') . "] Received amount: $amount\nInput: " . json_encode($data) . "\n", FILE_APPEND);

    if ($amount <= 0) {
        http_response_code(400);
        echo json_encode([
            'error' => 'Invalid amount',
            'received' => $data
        ]);
        exit;
    }

    // ✅ Create Razorpay Order (amount in paise)
    $order = $api->order->create([
        'amount'          => $amount * 100, // paise
        'currency'        => 'INR',
        'receipt'         => 'receipt_' . time(),
        'payment_capture' => 1
    ]);
    // Debug: Log the raw response and order object
    file_put_contents(__DIR__ . '/order_debug.log', "[" . date('Y-m-d H:i:s') . "] Raw order response: " . var_export($order, true) . "\n", FILE_APPEND);
    // Check if order is valid (object with id property)
    if (is_object($order) && isset($order->id)) {
        $orderArr = $order->toArray();
        file_put_contents(__DIR__ . '/order_debug.log', "[" . date('Y-m-d H:i:s') . "] Created order: " . json_encode($orderArr) . "\n", FILE_APPEND);
        echo json_encode($orderArr);
    } else {
        file_put_contents(__DIR__ . '/order_debug.log', "[" . date('Y-m-d H:i:s') . "] Order creation failed, response: " . json_encode($order) . "\n", FILE_APPEND);
        http_response_code(500);
        echo json_encode(['error' => 'Order creation failed', 'response' => $order]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Exception',
        'message' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
    exit;
}
